# Digital Marketing Course App

A simple Flutter application that displays key topics in Digital Marketing.

## Features
- Modern Flutter UI
- Course module listing
- Material Design components

## Modules
1. Introduction to Digital Marketing
2. Social Media Marketing
3. SEO
4. Freelancing
5. Content Marketing

## Author
Aliyu Nura
